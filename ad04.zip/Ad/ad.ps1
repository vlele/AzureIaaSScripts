Import-Module ActiveDirectory  
function createUser {    
param ([string] $ou, [string] $firstName, [string] $lastName, [string] $password, [string] $emailDomain)     
$userName = $firstName + "." + $lastName    
$fullName = $firstName + " " + $lastName   
$emailAddress = $username + "@" + $emailDomain   
New-ADUser -SamAccountName $userName -Name $fullName -DisplayName $fullName -GivenName $firstName -Surname $lastName -Path $ou -ChangePasswordAtLogon $false -AccountPassword (ConvertTo-SecureString -AsPlainText -String $password -Force) -Description $fullName -Enabled $true -EmailAddress $emailAddress -PasswordNeverExpires $true -UserPrincipalName $emailAddress 
}  
function createServiceUser {  
param ([string] $ou, [string] $userName, [string] $password, [string] $emailDomain)     
$emailAddress = $username + "@" + $emailDomain     
New-ADUser -SamAccountName $userName -Name $userName -DisplayName $fullName -Path $ou -ChangePasswordAtLogon $false -AccountPassword (ConvertTo-SecureString -AsPlainText -String $password -Force) -Description $userName -Enabled $true -EmailAddress $emailAddress -PasswordNeverExpires $true -UserPrincipalName $emailAddres
}  
$domain = [ADSI] "LDAP://dc=corp, dc=ais,dc=com"  
$ouServices = $domain.Create("OrganizationalUnit", "OU=Services")
$ouServices.SetInfo()  
$ouUserProfiles = $domain.Create("organizationalUnit", "ou=SharePoint Users") 
$ouUserProfiles.SetInfo()  
 
$ouUserProfilesEmployees = $ouUserProfiles.Create("organizationalUnit", "ou=Employees")
$ouUserProfilesEmployees.SetInfo()  
$services = [ADSI] "LDAP://ou=Services,dc=corp,dc=ais,dc=com"
$employees = [ADSI] "LDAP://ou=Employees,ou=SharePoint Users,dc=corp,dc=ais,dc=com"  
$fakePassword = "Passw0rd" 
$emailDomain = "corp.ais.com"  
 createServiceUser -ou $services.distinguishedName -userName "SPFarm" -password $fakePassword - emailDomain $emailDomain
createServiceUser -ou $services.distinguishedName -userName "SPService" -password $fakePassword - emailDomain $emailDomain
createServiceUser -ou $services.distinguishedName -userName "SPContent" -password $fakePassword - emailDomain $emailDomain
createServiceUser -ou $services.distinguishedName -userName "SPSearch" -password $fakePassword - emailDomain $emailDomain 
 createServiceUser -ou $services.distinguishedName -userName "SPUPS" -password $fakePassword - emailDomain $emailDomain 
 createServiceUser -ou $services.distinguishedName -userName "SQLService" -password $fakePassword - emailDomain $emailDomain
createServiceUser -ou $services.distinguishedName -userName "SQLAgent" -password $fakePassword - emailDomain $emailDomain
createServiceUser -ou $services.distinguishedName -userName "SQLReporting" -password $fakePassword -emailDomain $emailDomain  
$c = 1   
do {    
$firstName = "fn" + $c  
$lastName = "ln" + $c   
createUser -ou $employees.distinguishedName -firstName $firstName -lastName $lastName -password $fakePassword -emailDomain $emailDomain  
$c++
} while ($c -le 500)
