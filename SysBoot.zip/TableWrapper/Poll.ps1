$TaskRun = "powershell.exe -f c:\BootStrap\Scheduler\GetTasks.ps1"
schtasks /create /sc minute /mo 1 /tn "CIPT" /tr $TaskRun /ru System