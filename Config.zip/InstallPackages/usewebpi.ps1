$env:APPDATA="C:\Windows\Temp"
C:\WebPI\webpicmd /install /Application:WordPress@C:\WebPI\WordPress0.app /AcceptEula /MySQLPassword:pass@word1 >> c:\BootStrap\webpi.log