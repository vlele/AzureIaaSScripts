Import-Module WebAdministration
New-Item 'IIS:\Sites\Default Web Site\HealthCheck' -type Application -physicalPath 'C:\HealthCheck\'