Add-WindowsFeature -name NET-Framework-Features  >> c:\BootStrap\roles1.log
Add-WindowsFeature Web-Server -IncludeAllSubFeature >> c:\BootStrap\roles2.log
